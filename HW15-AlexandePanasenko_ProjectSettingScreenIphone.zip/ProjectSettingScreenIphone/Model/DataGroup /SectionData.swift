//
//  SectionData.swift
//  ProjectSettingScreenIphone
//
//  Created by MacBook Pro on 03.06.2022.

struct SectionData {
    let cells: [CellType]
}

