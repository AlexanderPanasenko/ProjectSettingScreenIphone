//
//  Additional.swift
//  ProjectSettingScreenIphone
//
//  Created by Alexander Panasenko on 03.06.2022.
//

import Foundation
 
public enum AdditionalType {
    case disclosureIcon
    case switchButton
}
