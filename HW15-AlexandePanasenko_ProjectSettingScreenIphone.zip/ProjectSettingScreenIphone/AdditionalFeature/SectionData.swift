//
//  SectionData.swift
//  ProjectSettingScreenIphone
//
//  Created by Alexander Panasenko on 26.06.2022.
//

struct SectionData {
    let cells: [CellType]
}
