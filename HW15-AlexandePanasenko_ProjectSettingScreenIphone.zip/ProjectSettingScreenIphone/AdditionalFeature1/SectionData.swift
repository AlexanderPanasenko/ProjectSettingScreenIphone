//
//  Change.swift
//  ProjectSettingScreenIphone
//
//  Created by Alexander Panasenko on 03.06.2022.
//

struct SectionData {
    let cells: [CellType]
}
